const appRouter = (app) => {
    const { check, validationResult } = require("express-validator/check");
    const Product = require("../models/product");
    const Category = require("../models/category");


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////Endpoint for adding new product////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    app.post("/newpro", [check("productName", "it's mandatory").not().isEmpty(),
    check("productCategory", "it's mandatory").not().isEmpty()],
        (req, res) => {
            const errors = validationResult(req);
            const category_ins = req.body.productCategory;
            let cat_obj = {};
            let cat_array = [];
            if (!errors.isEmpty()) 
                {
                    return res.status(400).json({ errors: errors.array() });
                }

            Category.find().sort({ category: 1 }).then((data) => {
                cat_obj = { AllCategories: data };


                //console.log(cat_obj.AllCategories.length);
                //console.log(cat_obj.AllCategories);
                for (var i = 0; i < cat_obj.AllCategories.length; i++) 
                    {
                        cat_array.push(cat_obj.AllCategories[i].category);
                    }

                //console.log(cat_array);
                //console.log(cat_array.includes(category_ins));
                if (cat_array.includes(category_ins)) //checking the existance of entered category
                    {
                        const product = new Product
                            ({
                                productName: req.body.productName,
                                productCategory: req.body.productCategory
                            });

                        product.save().then((data) => { //saving product after verifying entred category
                            res.send(data);
                        }).catch((err) => {
                            res.status(500).send({ message: "something went wrong" })
                        });
                    }
                else 
                    {
                        res.send({ message: "category does not exist" });
                    }
            });
        });

//__________________________________________________________________________________________________________________________________//


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////// Endpoint to add new category///////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    app.post("/newcat", [check("category", "it's mandatory").not().isEmpty()],
        (req, res) => {
            const errors = validationResult(req);
            if (!errors.isEmpty()) 
                {
                    return res.status(400).json({ errors: errors.array() });
                }

            const category = new Category({
                category: req.body.category
            });

            category.save().then((data) => {
                res.send(data);
            }).catch((err) => {
                res.status(500).send({ message: "something went wrong" })
            });
        });

//________________________________________________________________________________________________________________________________//



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////Endpoint to get list of all products////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    app.get("/getProducts", (req, res) => {
        Product.find().sort({ productName: 1 }).then((data) => {
            res.send({ AllProducts: data });
        }).catch((err) => {
            res.send({ message: err.message || "something went worng" })
        });
    });

//____________________________________________________________________________________________________________________//


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////Endpoint to get list of all categories//////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   
    app.get("/getCategories", (req, res) => {
        Category.find().sort({Category :1}).then((data) => { //sorting in ascending alphabatical order
            res.send({ AllCategories: data });
        }).catch((err) => {
            res.send({ message: err.message || "something went worng" })
        });
    });

//_________________________________________________________________________________________________________________________________//


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////Endpoint for getting nmber of products in every category////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    app.get("/output", (req, res) => {
        let cat_obj = {};
        let cat_array = [];
        let final_ans = [];

        Product.find().sort({ productCategory: 1 }).then((data) => { //sorting in ascending alphabaical order od category
            cat_obj = { AllCategories: data };//storing fetched data in array
            let count_repetition = {};

            //console.log(cat_obj.AllCategories.length);
            //console.log(cat_obj.AllCategories);
            for (var i = 0; i < cat_obj.AllCategories.length; i++) 
                {
                    cat_array.push(cat_obj.AllCategories[i].productCategory);
                }
            //console.log(cat_array);
            for (let i = 0; i < cat_array.length; i++) //counting repeatation on categories
                {
                    if (count_repetition[cat_array[i]]) 
                        {
                            count_repetition[cat_array[i]] += 1
                        }
                    else 
                        {
                            count_repetition[cat_array[i]] = 1 //for example {A:2,B:3,C:5}
                        }
                }

            const key_array = Object.keys(count_repetition);   //making an array of keys of count_repetition object
            const value_array = Object.values(count_repetition); //making an array of value of count repeatition object
            console.log(key_array);//[A,B,C]
            console.log(value_array);//[2,3,5]
            console.log(count_repetition);
            for (var i = 0; i < key_array.length; i++) 
                {
                    const obj =
                        {
                            category: key_array[i],
                            Number_of_products: value_array[i]
                        }
                    final_ans.push(obj); //final_ans array would be like = [{category: A,Number_of_products:2}....so on]
                }
            console.log(final_ans);
            res.send(final_ans);
        });
    });
}
//________________________________________________________________________________________________________________________//

module.exports = appRouter;