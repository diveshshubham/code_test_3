/////////////////////////////////////Category Schema /////////////////////////////////////////////////

const mongoose = require("mongoose");
const schema = mongoose.Schema(
    {
        category: {
            type: String,
            unique: true,
            required: true,
        },
    },
    {
        strict: true,
        versionKey: false,
        timestamps: { createdAt: "createdAt", updatedAt: "updatedAt" },
    }
);

module.exports = mongoose.model("Category", schema);