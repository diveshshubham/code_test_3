///////////////////////////////////////////////product schema///////////////////////////////////////

const mongoose = require("mongoose");
const pro_schema =  mongoose.Schema(
  {
    productName: {
        desc: "Product name",
        type: String,
        required: true,
      },
      productCategory: {
        desc: "Product's category",
        type: String,
        required: true,
      },
  },
  {
    timestamps: { createdAt: "createdAt", updatedAt: "updatedAt" },
  }
);

module.exports = mongoose.model("Product ", pro_schema);