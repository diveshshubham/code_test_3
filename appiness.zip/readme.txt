step-1 run command " npm install --save " in the project's root directory
step-2 set up your mongodb (I have done it locally)
step -3 run the project


first : add category 
second: add product in that category
third: 

first : add category 
    endpoint : http://localhost:8082/newcat
    Purpose : to add new category
    Method : Post
    sample data : 
                {
                    "category": "drinks"
                }


second: add product in that category
    endpoint : http://localhost:8082/newpro 
    Purpose : to add new product
    Method : Post
    sample data : 
                {
                    "productName": "clasberg-strong",
                    "productCategory": "drinks"
                }
    
third: 
endpoint : http://localhost:8082/output
Purpose :  to get the list of number of products in each listed category
Method : Get

endpoint : http://localhost:8082/getProducts     //////optional
Purpose : to get list of all getProducts
Method : Get


endpoint: http://localhost:8082/getCategories /////////////optional
Purpose : to get list of all categories
Method : Get


I will be making an object of repeatation categories and then counting the number of repetation in elements.


